const API_URL = 'http://localhost:3000/api/menu';
let allMenus = [];
let currentCategory = 'Semua';

// Kamus Gambar Berdasarkan Kata Kunci Nama Menu Spesifik
const foodDatabase = {
  burger: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop',
  nugget: 'https://images.unsplash.com/photo-1562967914-608f82629710?w=600&auto=format&fit=crop',
  pizza: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&auto=format&fit=crop',
  ayam: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=600&auto=format&fit=crop',
  kentang: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&auto=format&fit=crop',
  french: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&auto=format&fit=crop',
  spaghetti: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=600&auto=format&fit=crop',
  pasta: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=600&auto=format&fit=crop',
  steak: 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=600&auto=format&fit=crop',
  sushi: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=600&auto=format&fit=crop',
  ramen: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=600&auto=format&fit=crop',
  nasi: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=600&auto=format&fit=crop',
  kopi: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&auto=format&fit=crop',
  coffee: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&auto=format&fit=crop',
  teh: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop',
  tea: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop',
  jus: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=600&auto=format&fit=crop',
  juice: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=600&auto=format&fit=crop',
  boba: 'https://images.unsplash.com/photo-1558857563-b371033873b8?w=600&auto=format&fit=crop',
  donut: 'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=600&auto=format&fit=crop',
  donat: 'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=600&auto=format&fit=crop'
};

document.addEventListener('DOMContentLoaded', fetchMenu);

async function fetchMenu() {
  const container = document.getElementById('menu-grid');
  try {
    const response = await fetch(API_URL);
    const result = await response.json();
    
    allMenus = Array.isArray(result) ? result : (result.data || []);
    renderMenu();
  } catch (error) {
    console.error('Fetch Error:', error);
    container.innerHTML = `
      <div class="col-span-full bg-red-50 border border-red-200 text-red-700 p-6 rounded-2xl text-center">
        <i class="fa-solid fa-triangle-exclamation text-2xl mb-2"></i>
        <p class="font-bold">Gagal terhubung ke API Express Server</p>
        <p class="text-xs text-red-500 mt-1">Pastikan terminal backend sudah running di port 3000 (npm run dev)</p>
      </div>
    `;
  }
}

function renderMenu() {
  const container = document.getElementById('menu-grid');
  const searchVal = document.getElementById('search-input').value.toLowerCase();
  
  const filtered = allMenus.filter(item => {
    const matchCategory = currentCategory === 'Semua' || item.kategori === currentCategory;
    const matchSearch = item.nama.toLowerCase().includes(searchVal);
    return matchCategory && matchSearch;
  });

  document.getElementById('total-count').textContent = filtered.length;
  container.innerHTML = '';

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="col-span-full py-12 text-center text-slate-400">
        <i class="fa-solid fa-box-open text-4xl mb-3 text-slate-300"></i>
        <p class="font-semibold text-slate-600">Tidak ada menu ditemukan</p>
      </div>
    `;
    return;
  }

  filtered.forEach(item => {
    const priceFormatted = new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(item.harga);

    let badgeColor = 'bg-orange-500/10 text-orange-600 border-orange-500/20';
    if(item.kategori === 'Minuman') badgeColor = 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    if(item.kategori === 'Cemilan') badgeColor = 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';

    container.innerHTML += `
      <div class="group bg-white rounded-2xl shadow-sm hover:shadow-xl border border-slate-100 overflow-hidden transition-all duration-300 flex flex-col transform hover:-translate-y-1.5">
        <div class="relative h-52 bg-slate-100 overflow-hidden">
          <img src="${item.gambar}" alt="${item.nama}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
               onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop'">
          
          <div class="absolute top-3 left-3">
            <span class="px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider border backdrop-blur-md ${badgeColor}">
              ${item.kategori}
            </span>
          </div>

          <div class="absolute bottom-3 right-3 bg-slate-900/80 backdrop-blur-md px-2.5 py-1 rounded-lg text-amber-400 text-xs font-bold flex items-center gap-1 shadow">
            <i class="fa-solid fa-star"></i> 4.9
          </div>
        </div>

        <div class="p-5 flex-1 flex flex-col justify-between">
          <div>
            <h3 class="font-bold text-slate-900 text-lg group-hover:text-orange-500 transition line-clamp-1">${item.nama}</h3>
            <p class="text-xs text-slate-400 mt-1">Sajian lezat berkualitas tinggi</p>
          </div>

          <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
            <div>
              <span class="text-[10px] uppercase font-bold text-slate-400 block">Harga</span>
              <span class="text-lg font-extrabold text-slate-900">${priceFormatted}</span>
            </div>

            <button onclick="deleteMenu(${item.id})" class="w-9 h-9 rounded-xl bg-red-50 text-red-500 hover:bg-red-500 hover:text-white transition-colors duration-200 flex items-center justify-center shadow-sm">
              <i class="fa-solid fa-trash-can text-sm"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  });
}

function setCategory(cat) {
  currentCategory = cat;
  document.querySelectorAll('.filter-tab').forEach(tab => {
    tab.className = 'filter-tab bg-white text-slate-600 hover:text-slate-900 px-5 py-2.5 rounded-xl font-semibold text-sm transition shadow-sm border border-slate-200';
  });
  event.target.className = 'filter-tab active-tab bg-slate-900 text-white px-5 py-2.5 rounded-xl font-semibold text-sm transition shadow-sm border border-slate-800';
  renderMenu();
}

function filterMenu() {
  renderMenu();
}

function openModal() {
  const modal = document.getElementById('modal-form');
  const card = modal.querySelector('.modal-card');
  modal.classList.remove('hidden');
  modal.classList.add('flex');
  setTimeout(() => {
    card.classList.remove('scale-95', 'opacity-0');
    card.classList.add('scale-100', 'opacity-100');
  }, 10);
}

function closeModal() {
  const modal = document.getElementById('modal-form');
  const card = modal.querySelector('.modal-card');
  card.classList.remove('scale-100', 'opacity-100');
  card.classList.add('scale-95', 'opacity-0');
  setTimeout(() => {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    document.getElementById('form-menu').reset();
  }, 200);
}

async function saveMenu(e) {
  e.preventDefault();
  
  const nama = document.getElementById('nama').value.trim();
  const kategori = document.getElementById('kategori').value;
  const harga = document.getElementById('harga').value;
  let gambar = document.getElementById('gambar').value.trim();

  // Logika Pencarian Gambar Otomatis Berdasarkan Kata Kunci Nama Menu
  if (!gambar) {
    const namaLower = nama.toLowerCase();
    
    // Cari kata kunci terdekat di database preset
    const matchedKey = Object.keys(foodDatabase).find(key => namaLower.includes(key));
    
    if (matchedKey) {
      gambar = foodDatabase[matchedKey];
    } else {
      // Jika kata kunci belum terdaftar di database, ambil gambar pencarian otomatis dari Unsplash
      gambar = `https://source.unsplash.com/featured/?${encodeURIComponent(nama)},food`;
    }
  }

  const data = { nama, kategori, harga, gambar };

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (res.ok) {
      closeModal();
      fetchMenu();
    } else {
      alert('Gagal menyimpan menu');
    }
  } catch (err) {
    console.error(err);
  }
}

async function deleteMenu(id) {
  if (!confirm('Yakin ingin menghapus menu ini?')) return;
  try {
    const res = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
    if (res.ok) fetchMenu();
  } catch (err) {
    console.error(err);
  }
}